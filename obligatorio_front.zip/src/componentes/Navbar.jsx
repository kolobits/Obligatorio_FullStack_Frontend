import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router";
import { useDispatch } from "react-redux";
import { borrarToken } from "../store/slices/usuarioSlice";

const Navbar = () => {

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [nombre, setNombre] = useState("");

  useEffect(() => {
    if (localStorage.getItem("token") === null) {
      navigate("/");
    } else {
      fetch("https://obligatorio1-fullstack.vercel.app/v1/usuarios/perfil", {
        headers: {
          'Authorization': localStorage.getItem("token"),
        }
      })
        .then(r => r.json())
        .then(datos => {
          console.log(datos);
          setNombre(datos.username);
        })
    }
  }, [])

  const logout = () => {
    localStorage.clear();
    dispatch(borrarToken());
    navigate("/");
  }

  return (
    <div>
      <nav className="navbar navbar-expand-md barra py-0">
        <div className="container">
          <Link className="marca py-3" to="/dashboard">
            <span className="marca-icono"><i className="bi bi-airplane-fill"></i></span>
            Planificador
          </Link>
          <button className="navbar-toggler" type="button" aria-label="Abrir menú">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="menu">
            <ul className="navbar-nav ms-md-4 me-auto">
              <li className="nav-item"><NavLink className="nav-link" to="/dashboard">Mis viajes</NavLink></li>
              <li className="nav-item"><NavLink className="nav-link" to="/categorias">Categorías</NavLink></li>
            </ul>
            <ul className="navbar-nav">
              <li className="nav-item"><NavLink className="nav-link" to="/perfil"><i className="bi bi-person-circle"></i> {nombre}</NavLink></li>
              <li className="nav-item"><button type="button" className="nav-link" onClick={logout}>Cerrar sesión</button></li>
            </ul>
          </div>
        </div>
      </nav>
      <Outlet />
    </div>
  );
};

export default Navbar;